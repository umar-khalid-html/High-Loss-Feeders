# Deployment Guide – IESCO High Loss Feeder AMI Dashboard

## Step-by-step (recommended path)

### A. Google Sheet (backend)

1. Create a new Google Spreadsheet named **IESCO High Loss Feeder AMI Progress**.
2. Rename the first sheet to **Meter_Data**.
3. Add a second sheet named **Feeder_Master**.
4. Paste the headers and sample data from:
   - `sample-data/Meter_Data_Sample.csv` → Meter_Data
   - `sample-data/Feeder_Master.csv` → Feeder_Master
5. **Critical**: Select columns H (Reference Number) and I (New Meter No.) → Format → Number → **Plain text**.
6. (Optional) Create sheets named Instructions, Dashboard_Summary, Validation.

### B. Apps Script API

1. In the spreadsheet: **Extensions → Apps Script**.
2. Delete any default code.
3. Paste the entire content of `apps-script/Code.gs`.
4. Save (Ctrl+S). Name the project `AMI Dashboard API`.
5. Click **Deploy → New deployment**.
6. Click the gear icon → choose **Web app**.
7. Settings:
   - Description: `AMI Dashboard Data API`
   - Execute as: **Me**
   - Who has access: **Anyone**
8. Click **Deploy**.
9. Authorise the script when prompted.
10. **Copy the Web App URL** (looks like `https://script.google.com/macros/s/XXXX/exec`).

### C. Dashboard configuration

1. Open `script.js`.
2. Find the line:
   ```js
   const GOOGLE_SHEET_API_URL = '';
   ```
3. Paste your Web App URL between the quotes:
   ```js
   const GOOGLE_SHEET_API_URL = 'https://script.google.com/macros/s/XXXX/exec';
   ```
4. Save.

### D. GitHub Pages

1. Create a new public GitHub repository (e.g. `iesco-ami-high-loss-dashboard`).
2. Upload these files to the root of the repository:
   - `index.html`
   - `style.css`
   - `script.js`
   - `README.md` (optional)
3. Go to **Settings → Pages**.
4. Under “Build and deployment”:
   - Source: **Deploy from a branch**
   - Branch: `main` (or `master`) / folder: `/ (root)`
5. Click **Save**.
6. After 1–2 minutes the site will be live at:
   `https://<your-username>.github.io/iesco-ami-high-loss-dashboard/`

### E. Verify

1. Open the GitHub Pages URL.
2. You should see the live pulse indicator and real data from the Google Sheet.
3. Add a test row in Meter_Data and click **Refresh Data** on the dashboard – the new record should appear.

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---------|--------------|-----|
| “Demo Mode” banner stays on | API URL empty or wrong | Check `GOOGLE_SHEET_API_URL` |
| CORS / fetch error | Web App not set to “Anyone” | Re-deploy with correct access |
| Empty tables | Sheet names mismatch | Must be exactly `Meter_Data` and `Feeder_Master` |
| Leading zeros lost | Columns not Plain text | Format H & I as Plain text before paste |
| Charts missing | Chart.js CDN blocked | Check network / firewall |

---

## Updating data after go-live

- Only edit **Meter_Data**.
- Never change column order without updating the Apps Script column mapping.
- New feeders: add a row to **Feeder_Master**; they appear automatically.
- Dashboard auto-refreshes every 5 minutes; use the Refresh button for immediate update.

# Instructions for Data Entry Team – IESCO High Loss Feeder AMI Progress

## Purpose
This Google Sheet is the single source of truth for the live AMI Progress Dashboard used by management.

## Sheets Overview

| Sheet            | Purpose                                      | Who edits          |
|------------------|----------------------------------------------|--------------------|
| Meter_Data       | Main database – add / update meter records   | Field / Data team  |
| Feeder_Master    | Fixed list of 10 High Loss Feeders           | Admin only         |
| Instructions     | This document                                | Read-only          |
| Dashboard_Summary| Optional – left blank (dashboard calculates) | System             |
| Validation       | Optional helper                              | System             |

## How to Add a New Meter Record

1. Go to sheet **Meter_Data**.
2. Scroll to the first empty row.
3. Fill the columns in this order:

| Column              | Rule / Example                              |
|---------------------|---------------------------------------------|
| Sr. No.             | Sequential number                           |
| Installation Date   | DD/MM/YYYY e.g. 15/09/2026                  |
| Division            | Exact name e.g. TARIQABAD                   |
| Sub Division        | Exact name e.g. CHAKRI                      |
| Feeder              | Must match Feeder_Master exactly            |
| TR ID               | Transformer ID. Put **N/A** if not available|
| TR Capacity         | kVA rating. Leave blank or N/A if missing   |
| Reference Number    | **Keep as text** – do not let Excel convert |
| New Meter No.       | **Keep as text** – preserve leading zeros   |
| Old Meter No.       | Optional                                    |
| Remarks             | e.g. “Installed and Commissioned” or “Provide TR ID and T/F Cap” |

4. **Important – Text formatting**
   - Before pasting Reference Number and New Meter No., select the cells → Format → Number → Plain text.
   - This prevents Google Sheets from removing leading zeros.

5. Save. The live dashboard will pick up the new row on the next refresh (or within 5 minutes).

## Status Logic (automatic)

The dashboard automatically classifies every record:

- **Completed** – TR ID present, Capacity present, Reference valid, Meter valid, no duplicates, and remarks indicate installed/commissioned.
- **Pending Data** – Any of TR ID, Capacity or Reference missing / N/A.
- **Duplicate Record** – Same Reference Number or same Meter Number appears more than once.
- **Other Issue** – Remarks indicate a different problem.

You do **not** need to fill the status columns manually.

## Feeder Names – Exact Match Required

Use these exact feeder names (case-insensitive but spelling must match):

1. U.TOPA
2. CHIRAH
3. TUMAIR (NILORE)
4. MAIRA SHAROF
5. PASWAL
6. CHAKRI
7. PARYAL
8. REHARA
9. WAHEED ABAD
10. PIR SOHAWA

## Common Mistakes to Avoid

- Changing Feeder_Master without coordinating with the dashboard owner.
- Entering meter / reference numbers as numbers (leading zeros disappear).
- Using different spellings for the same feeder.
- Deleting historical rows – keep all records for audit.

## Contact

For dashboard technical issues or to add new feeders, contact the AMI Operation Center.

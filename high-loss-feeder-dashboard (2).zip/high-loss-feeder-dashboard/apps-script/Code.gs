/**
 * IESCO High Loss Feeder AMI Progress – Google Apps Script Web App
 * Deploy as Web App → Execute as Me → Anyone
 * Returns JSON for the GitHub Pages dashboard.
 */

const METER_SHEET_NAME   = 'Meter_Data';
const FEEDER_SHEET_NAME  = 'Feeder_Master';

/**
 * Main entry point for the Web App.
 * Supports both GET (dashboard fetch) and OPTIONS (CORS pre-flight).
 */
function doGet(e) {
  return handleRequest(e);
}

function doPost(e) {
  return handleRequest(e);
}

function handleRequest(e) {
  try {
    const action = (e && e.parameter && e.parameter.action) ? e.parameter.action : 'getData';

    let result;
    switch (action) {
      case 'getData':
        result = getDashboardData();
        break;
      case 'refreshValidation':
        result = refreshValidation();
        break;
      default:
        result = { success: false, error: 'Unknown action' };
    }

    return createJsonResponse(result);
  } catch (err) {
    return createJsonResponse({
      success: false,
      error: err.message,
      stack: err.stack
    });
  }
}

/**
 * Returns complete dataset needed by the dashboard.
 */
function getDashboardData() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const meterSheet  = ss.getSheetByName(METER_SHEET_NAME);
  const feederSheet = ss.getSheetByName(FEEDER_SHEET_NAME);

  if (!meterSheet) {
    throw new Error('Sheet "Meter_Data" not found');
  }

  // ---- Feeder Master ----
  let feeders = [];
  if (feederSheet) {
    const fData = feederSheet.getDataRange().getValues();
    // Assume header row
    for (let i = 1; i < fData.length; i++) {
      const row = fData[i];
      if (!row[0] && !row[3]) continue; // skip empty
      feeders.push({
        sr:          String(row[0] || '').trim(),
        division:    String(row[1] || '').trim().toUpperCase(),
        subDivision: String(row[2] || '').trim().toUpperCase(),
        feeder:      String(row[3] || '').trim().toUpperCase()
      });
    }
  }

  // Fallback master list if sheet missing
  if (feeders.length === 0) {
    feeders = getDefaultFeederMaster();
  }

  // ---- Meter Data ----
  const data = meterSheet.getDataRange().getValues();
  if (data.length < 2) {
    return {
      success: true,
      lastUpdated: new Date().toISOString(),
      feeders: feeders,
      records: []
    };
  }

  const headers = data[0].map(h => String(h).trim());
  const col = {};
  headers.forEach((h, idx) => { col[h] = idx; });

  // Helper to safely get cell
  const cell = (row, name, altNames) => {
    let idx = col[name];
    if (idx === undefined && altNames) {
      for (const a of altNames) {
        if (col[a] !== undefined) { idx = col[a]; break; }
      }
    }
    if (idx === undefined) return '';
    let v = row[idx];
    if (v === null || v === undefined) return '';
    if (Object.prototype.toString.call(v) === '[object Date]') {
      return Utilities.formatDate(v, Session.getScriptTimeZone(), 'dd/MM/yyyy');
    }
    return String(v).trim();
  };

  const records = [];
  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    // Skip completely empty rows
    if (row.every(c => c === '' || c === null)) continue;

    const rec = {
      srNo:            cell(row, 'Sr. No.', ['Sr No', 'Sr.No.', 'S.No']),
      installationDate: cell(row, 'Installation Date', ['Install Date', 'Date']),
      division:        cell(row, 'Division').toUpperCase(),
      subDivision:     cell(row, 'Sub Division', ['Sub-Division', 'Subdivision']).toUpperCase(),
      feeder:          cell(row, 'Feeder').toUpperCase(),
      trId:            cell(row, 'TR ID', ['TRID', 'Transformer ID']),
      trCapacity:      cell(row, 'TR Capacity', ['Capacity', 'T/F Capacity', 'TF Capacity']),
      referenceNumber: cell(row, 'Reference Number', ['Ref No', 'Reference No', 'Ref. Number']),
      newMeterNo:      cell(row, 'New Meter No.', ['New Meter No', 'Meter No', 'New Meter Number']),
      oldMeterNo:      cell(row, 'Old Meter No.', ['Old Meter No', 'Old Meter']),
      remarks:         cell(row, 'Remarks'),
      lastUpdated:     cell(row, 'Last Updated'),
      updatedBy:       cell(row, 'Updated By')
    };

    // Normalise feeder name to match master (simple cleanup)
    rec.feeder = normaliseFeederName(rec.feeder);

    records.push(rec);
  }

  // Run validation on the server side as well (client will re-validate)
  const validated = validateRecords(records);

  return {
    success: true,
    lastUpdated: new Date().toISOString(),
    feeders: feeders,
    records: validated
  };
}

/**
 * Server-side validation – mirrors the client logic.
 */
function validateRecords(records) {
  // Count occurrences for duplicate detection
  const refCount  = {};
  const meterCount = {};

  records.forEach(r => {
    const ref = (r.referenceNumber || '').trim();
    const met = (r.newMeterNo || '').trim();
    if (ref && ref.toUpperCase() !== 'N/A') {
      refCount[ref] = (refCount[ref] || 0) + 1;
    }
    if (met && met.toUpperCase() !== 'N/A') {
      meterCount[met] = (meterCount[met] || 0) + 1;
    }
  });

  return records.map(r => {
    const trId     = (r.trId || '').trim();
    const capacity = (r.trCapacity || '').trim();
    const ref      = (r.referenceNumber || '').trim();
    const meter    = (r.newMeterNo || '').trim();
    const remarks  = (r.remarks || '').toLowerCase();

    // TR ID status
    const trIdMissing = !trId || trId.toUpperCase() === 'N/A' || trId === '-' || trId === '';
    r.trIdStatus = trIdMissing ? 'Pending' : 'OK';

    // Capacity status
    const capMissing = !capacity || capacity.toUpperCase() === 'N/A' || capacity === '-' || capacity === '';
    r.capacityStatus = capMissing ? 'Pending' : 'OK';

    // Duplicates
    r.refDuplicate   = (ref && ref.toUpperCase() !== 'N/A' && refCount[ref] > 1) ? 'Yes' : 'No';
    r.meterDuplicate = (meter && meter.toUpperCase() !== 'N/A' && meterCount[meter] > 1) ? 'Yes' : 'No';
    r.refDuplicateCount   = refCount[ref] || 0;
    r.meterDuplicateCount = meterCount[meter] || 0;

    // Overall Data Status
    if (r.refDuplicate === 'Yes' || r.meterDuplicate === 'Yes') {
      r.dataStatus = 'Duplicate Record';
    } else if (trIdMissing || capMissing) {
      r.dataStatus = 'Pending Data';
    } else if (remarks.includes('provide') || remarks.includes('missing') || remarks.includes('pending')) {
      r.dataStatus = 'Pending Data';
    } else if (remarks.includes('installed') || remarks.includes('commissioned')) {
      r.dataStatus = 'Completed';
    } else if (remarks.trim() !== '') {
      r.dataStatus = 'Other Issue';
    } else {
      // Default when everything looks present
      r.dataStatus = (trIdMissing || capMissing) ? 'Pending Data' : 'Completed';
    }

    // Installation Status helper
    r.installationStatus = (remarks.includes('installed') || remarks.includes('commissioned'))
      ? 'Installed & Commissioned'
      : (r.dataStatus === 'Completed' ? 'Installed & Commissioned' : 'Pending');

    return r;
  });
}

/**
 * Optional: write validation columns back into the sheet.
 * Call manually from the Apps Script editor if desired.
 */
function refreshValidation() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(METER_SHEET_NAME);
  if (!sheet) return { success: false, error: 'Meter_Data not found' };

  const data = sheet.getDataRange().getValues();
  if (data.length < 2) return { success: true, message: 'No data' };

  // We re-use getDashboardData logic
  const payload = getDashboardData();
  // For simplicity we just return success; writing back can be added later
  return { success: true, message: 'Validation refreshed', recordCount: payload.records.length };
}

/**
 * Default feeder master (used if Feeder_Master sheet is missing).
 */
function getDefaultFeederMaster() {
  return [
    { sr: '1',  division: 'BHARA KAHU',   subDivision: 'PATRIATA',         feeder: 'U.TOPA' },
    { sr: '2',  division: 'ISLAMABAD-I',  subDivision: 'NILORE',           feeder: 'CHIRAH' },
    { sr: '3',  division: 'ISLAMABAD-I',  subDivision: 'NILORE',           feeder: 'TUMAIR (NILORE)' },
    { sr: '4',  division: 'PINDI GHEB',   subDivision: 'CHHAB',            feeder: 'MAIRA SHAROF' },
    { sr: '5',  division: 'TAXILA',       subDivision: 'SANGJANI',         feeder: 'PASWAL' },
    { sr: '6',  division: 'TARIQABAD',    subDivision: 'CHAKRI',           feeder: 'CHAKRI' },
    { sr: '7',  division: 'TARIQABAD',    subDivision: 'CHAKRI',           feeder: 'PARYAL' },
    { sr: '8',  division: 'BHARA KAHU',   subDivision: 'BHARA KAHU',       feeder: 'REHARA' },
    { sr: '9',  division: 'ISLAMABAD-I',  subDivision: 'RAWAL',            feeder: 'WAHEED ABAD' },
    { sr: '10', division: 'BHARA KAHU',   subDivision: 'BHARA KAHU RURAL', feeder: 'PIR SOHAWA' }
  ];
}

/**
 * Light normalisation so "U. Topa", "U.TOPA", "U TOPA" etc. match.
 */
function normaliseFeederName(name) {
  if (!name) return '';
  let n = name.toUpperCase().trim();
  n = n.replace(/\s+/g, ' ');
  // Common variants
  if (n.includes('TOPA')) return 'U.TOPA';
  if (n.includes('CHIRAH')) return 'CHIRAH';
  if (n.includes('TUMAIR')) return 'TUMAIR (NILORE)';
  if (n.includes('MAIRA')) return 'MAIRA SHAROF';
  if (n.includes('PASWAL')) return 'PASWAL';
  if (n === 'CHAKRI') return 'CHAKRI';
  if (n.includes('PARYAL')) return 'PARYAL';
  if (n.includes('REHARA')) return 'REHARA';
  if (n.includes('WAHEED')) return 'WAHEED ABAD';
  if (n.includes('PIR SOHAWA') || n.includes('PIRSOHAWA')) return 'PIR SOHAWA';
  return n;
}

/**
 * JSON response with CORS headers.
 */
function createJsonResponse(obj) {
  const output = ContentService.createTextOutput(JSON.stringify(obj));
  output.setMimeType(ContentService.MimeType.JSON);
  return output;
}

/**
 * Test function – run from Apps Script editor to verify.
 */
function testGetData() {
  const result = getDashboardData();
  Logger.log(JSON.stringify(result, null, 2));
}

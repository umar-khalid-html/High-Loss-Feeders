# IESCO High Loss Feeders – AMI Progress Monitoring Dashboard

**Official operational monitoring system for AMI meter installation, commissioning and data verification on 10 High Loss Feeders.**

## Overview

Management-focused live dashboard that pulls data dynamically from a Google Sheet.  
No hard-coded statistics — all KPIs, progress bars, charts and tables are calculated from live data.

### Key Features
- Top KPI cards (Total Feeders, Records, Completed, Pending, TR ID Pending, Capacity Pending, Duplicates, Overall %)
- Feeder-wise progress table with progress bars (all 10 feeders always shown)
- Subdivision Pending Data section (most prominent operational view)
- Interactive charts (Feeder progress, Pending classification, Division progress, Installation trend)
- Searchable / filterable / sortable / paginated detailed record table
- CSV & Excel export
- Status badges with clear labels (not colour-only)
- Live Monitoring pulse indicator + Last Data Update timestamp
- Fully responsive (desktop priority)

---

## 1. Google Sheet Setup

### Create a new Google Spreadsheet
Name it: `IESCO High Loss Feeder AMI Progress`

### Sheet 1 – Meter_Data (Primary database)

| Column | Header                | Notes                                      |
|--------|-----------------------|--------------------------------------------|
| A      | Sr. No.               | Auto or manual                             |
| B      | Installation Date     | DD/MM/YYYY (text or date)                  |
| C      | Division              |                                            |
| D      | Sub Division          |                                            |
| E      | Feeder                | Must match Feeder_Master exactly           |
| F      | TR ID                 | Text – keep as text                        |
| G      | TR Capacity           | Text / number                              |
| H      | Reference Number      | **Text** (preserve leading zeros)          |
| I      | New Meter No.         | **Text** (preserve leading zeros)          |
| J      | Old Meter No.         | Optional                                   |
| K      | Ref No. Duplicate     | Formula or Apps Script fills               |
| L      | Meter No. Duplicate   | Formula or Apps Script fills               |
| M      | TR ID Status          | Auto                                       |
| N      | Capacity Status       | Auto                                       |
| O      | Installation Status   |                                            |
| P      | Data Status           | Auto (Completed / Pending Data / Duplicate / Other Issue) |
| Q      | Remarks               |                                            |
| R      | Last Updated          | Timestamp                                  |
| S      | Updated By            |                                            |

**Important data-entry rules**
- Format columns H and I as **Plain text** before pasting.
- Use DD/MM/YYYY for Installation Date.
- Leave TR Capacity blank or put `N/A` when missing.
- Put `N/A` in TR ID when not available.

### Sheet 2 – Feeder_Master (Fixed list – do not change order)

| Sr. | Division     | Sub Division      | Feeder           |
|-----|--------------|-------------------|------------------|
| 1   | BHARA KAHU   | PATRIATA          | U.TOPA           |
| 2   | ISLAMABAD-I  | NILORE            | CHIRAH           |
| 3   | ISLAMABAD-I  | NILORE            | TUMAIR (NILORE)  |
| 4   | PINDI GHEB   | CHHAB             | MAIRA SHAROF     |
| 5   | TAXILA       | SANGJANI          | PASWAL           |
| 6   | TARIQABAD    | CHAKRI            | CHAKRI           |
| 7   | TARIQABAD    | CHAKRI            | PARYAL           |
| 8   | BHARA KAHU   | BHARA KAHU        | REHARA           |
| 9   | ISLAMABAD-I  | RAWAL             | WAHEED ABAD      |
| 10  | BHARA KAHU   | BHARA KAHU RURAL  | PIR SOHAWA       |

### Sheet 3 – Instructions
Paste the content of `docs/Instructions.md` (or the section below) into this sheet.

### Sheet 4 – Dashboard_Summary (optional – can be left empty; dashboard calculates everything client-side)

### Sheet 5 – Validation (optional helper)

---

## 2. Google Apps Script (Web App API)

1. In the Google Sheet go to **Extensions → Apps Script**.
2. Delete any existing code and paste the entire contents of `apps-script/Code.gs`.
3. Save the project (name it `AMI Dashboard API`).
4. Click **Deploy → New deployment**.
5. Select type **Web app**.
6. Execute as: **Me**
7. Who has access: **Anyone** (or “Anyone with Google account” if you prefer restricted access).
8. Deploy and **copy the Web App URL**.
9. Open `script.js` in the dashboard and replace the placeholder:

```js
const GOOGLE_SHEET_API_URL = 'YOUR_WEB_APP_URL_HERE';
```

---

## 3. Sample Data

Use the 35 sample records provided in the original requirement.  
A ready-to-paste CSV is available in `sample-data/Meter_Data_Sample.csv`.

After pasting:
- Select columns H & I → Format → Number → Plain text.
- Re-run the Apps Script function `refreshValidation` (or just refresh the dashboard).

---

## 4. GitHub Pages Deployment

### Option A – Multi-file (recommended)

```
high-loss-feeder-dashboard/
├── index.html
├── style.css
├── script.js
├── README.md
└── apps-script/
    └── Code.gs
```

1. Create a new GitHub repository.
2. Upload the files.
3. Go to **Settings → Pages**.
4. Source: Deploy from a branch → `main` / root.
5. Save. Your dashboard will be live at `https://<username>.github.io/<repo>/`.

### Option B – Single-file

A self-contained `index-single.html` is also provided.  
Simply upload it as `index.html` to any GitHub Pages repository.

---

## 5. How the Dashboard Works

1. On load (and every 5 minutes) the dashboard calls the Google Apps Script Web App.
2. The script returns the entire `Meter_Data` sheet as JSON + the Feeder Master list.
3. Client-side JavaScript:
   - Validates every record (missing TR ID, missing Capacity, duplicates, etc.)
   - Calculates all KPIs
   - Builds feeder-wise and subdivision-wise summaries
   - Renders charts (Chart.js via CDN)
   - Populates the detailed DataTable
4. Filters, search, sort and export work entirely in the browser.

**No Node.js, no build step, no backend server required.**

---

## 6. Status Logic (Client-side)

| Condition                                      | Status            |
|------------------------------------------------|-------------------|
| TR ID present + Capacity present + Ref valid + Meter valid + no duplicates + Remarks indicate installed/commissioned | **Completed**     |
| TR ID missing / N/A or Capacity missing        | **Pending Data**  |
| Reference Number or Meter Number duplicated    | **Duplicate Record** |
| Other remarks / issues                         | **Other Issue**   |

---

## 7. Maintenance

- **Add new meters**: Just append rows to `Meter_Data`. Dashboard updates on next refresh.
- **Add new feeders**: Add a row to `Feeder_Master` and the feeder will appear automatically.
- **Never hard-code counts** in the HTML/JS – everything is dynamic.

---

## 8. Browser Support

Chrome, Edge, Firefox, Safari (latest two versions).  
Desktop/laptop is the primary target; tablet and mobile are fully responsive.

---

**AMI Operation Center | IESCO**  
*Live monitoring of High Loss Feeder meter installation & data verification*

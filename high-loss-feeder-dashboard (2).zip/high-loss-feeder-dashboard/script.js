/**
 * IESCO High Loss Feeders – AMI Progress Monitoring Dashboard
 * Client-side logic: fetch → validate → aggregate → render
 */

// ============================================================
// CONFIGURATION – Replace with your Google Apps Script Web App URL
// ============================================================
const GOOGLE_SHEET_API_URL = ''; // ← PASTE YOUR WEB APP URL HERE

// Auto-refresh interval (ms). Set to 0 to disable.
const AUTO_REFRESH_MS = 5 * 60 * 1000; // 5 minutes

// ============================================================
// FIXED FEEDER MASTER (always shown even with zero records)
// ============================================================
const DEFAULT_FEEDERS = [
  { sr: '1',  division: 'BHARA KAHU',   subDivision: 'PATRIATA',         feeder: 'U.TOPA' },
  { sr: '2',  division: 'ISLAMABAD-I',  subDivision: 'NILORE',           feeder: 'CHIRAH' },
  { sr: '3',  division: 'ISLAMABAD-I',  subDivision: 'NILORE',           feeder: 'TUMAIR (NILORE)' },
  { sr: '4',  division: 'PINDI GHEB',   subDivision: 'CHHAB',            feeder: 'MAIRA SHAROF' },
  { sr: '5',  division: 'TAXILA',       subDivision: 'SANGJANI',         feeder: 'PASWAL' },
  { sr: '6',  division: 'TARIQABAD',    subDivision: 'CHAKRI',           feeder: 'CHAKRI' },
  { sr: '7',  division: 'TARIQABAD',    subDivision: 'CHAKRI',           feeder: 'PARYAL' },
  { sr: '8',  division: 'BHARA KAHU',   subDivision: 'BHARA KAHU',       feeder: 'REHARA' },
  { sr: '9',  division: 'ISLAMABAD-I',  subDivision: 'RAWAL',            feeder: 'WAHEED ABAD' },
  { sr: '10', division: 'BHARA KAHU',   subDivision: 'BHARA KAHU RURAL', feeder: 'PIR SOHAWA' }
];

// ============================================================
// SAMPLE DATA (used when API URL is empty – demo mode)
// ============================================================
const SAMPLE_RECORDS = [
  { srNo:'1',  installationDate:'07/09/2026', division:'TARIQABAD',   subDivision:'CHAKRI',   feeder:'PARYAL',  trId:'16759',  trCapacity:'', referenceNumber:'21146265276997', newMeterNo:'02322400005380', remarks:'Installed and Commissioned' },
  { srNo:'2',  installationDate:'07/09/2026', division:'TARIQABAD',   subDivision:'CHAKRI',   feeder:'PARYAL',  trId:'17096',  trCapacity:'', referenceNumber:'22146263405315', newMeterNo:'02322400005315', remarks:'Installed and Commissioned' },
  { srNo:'3',  installationDate:'07/09/2026', division:'TARIQABAD',   subDivision:'CHAKRI',   feeder:'PARYAL',  trId:'17097',  trCapacity:'', referenceNumber:'22146263581876', newMeterNo:'02322400005147', remarks:'Installed and Commissioned' },
  { srNo:'4',  installationDate:'07/09/2026', division:'TARIQABAD',   subDivision:'CHAKRI',   feeder:'PARYAL',  trId:'90354',  trCapacity:'', referenceNumber:'23146262381563', newMeterNo:'02322400005144', remarks:'Installed and Commissioned' },
  { srNo:'5',  installationDate:'07/09/2026', division:'TARIQABAD',   subDivision:'CHAKRI',   feeder:'PARYAL',  trId:'17179',  trCapacity:'', referenceNumber:'23146260181803', newMeterNo:'02322400005224', remarks:'CT Meter is already installed on this TF' },
  { srNo:'6',  installationDate:'07/09/2026', division:'TARIQABAD',   subDivision:'CHAKRI',   feeder:'PARYAL',  trId:'26873',  trCapacity:'', referenceNumber:'23146261277257', newMeterNo:'02322400005371', remarks:'Installed and Commissioned' },
  { srNo:'7',  installationDate:'07/09/2026', division:'TARIQABAD',   subDivision:'CHAKRI',   feeder:'PARYAL',  trId:'90352',  trCapacity:'', referenceNumber:'23146262181564', newMeterNo:'02322400005310', remarks:'Installed and Commissioned' },
  { srNo:'8',  installationDate:'07/09/2026', division:'TARIQABAD',   subDivision:'CHAKRI',   feeder:'PARYAL',  trId:'90350',  trCapacity:'', referenceNumber:'23146261905430', newMeterNo:'02322400005430', remarks:'Installed and Commissioned' },
  { srNo:'9',  installationDate:'07/09/2026', division:'ISLAMABAD-I', subDivision:'NILORE',   feeder:'CHIRAH',  trId:'N/A',    trCapacity:'', referenceNumber:'03141189001269', newMeterNo:'02322400005358', remarks:'Provide TR ID and T/F Cap' },
  { srNo:'10', installationDate:'07/09/2026', division:'ISLAMABAD-I', subDivision:'NILORE',   feeder:'CHIRAH',  trId:'N/A',    trCapacity:'', referenceNumber:'03141189001201', newMeterNo:'02322400005425', remarks:'Provide TR ID and T/F Cap' },
  { srNo:'11', installationDate:'07/09/2026', division:'ISLAMABAD-I', subDivision:'NILORE',   feeder:'CHIRAH',  trId:'N/A',    trCapacity:'', referenceNumber:'03141189001200', newMeterNo:'02322400005420', remarks:'Provide TR ID and T/F Cap' },
  { srNo:'12', installationDate:'07/09/2026', division:'ISLAMABAD-I', subDivision:'NILORE',   feeder:'CHIRAH',  trId:'N/A',    trCapacity:'', referenceNumber:'03141189001274', newMeterNo:'02322400005351', remarks:'Provide TR ID and T/F Cap' },
  { srNo:'13', installationDate:'07/09/2026', division:'ISLAMABAD-I', subDivision:'NILORE',   feeder:'CHIRAH',  trId:'N/A',    trCapacity:'', referenceNumber:'03141189001157', newMeterNo:'02322400005251', remarks:'Provide TR ID and T/F Cap' },
  { srNo:'14', installationDate:'07/09/2026', division:'ISLAMABAD-I', subDivision:'NILORE',   feeder:'CHIRAH',  trId:'N/A',    trCapacity:'', referenceNumber:'03141189001156', newMeterNo:'02322400005346', remarks:'Provide TR ID and T/F Cap' },
  { srNo:'15', installationDate:'07/09/2026', division:'BHARA KAHU',  subDivision:'PATRIATA', feeder:'U.TOPA',  trId:'N/A',    trCapacity:'', referenceNumber:'01141349000664', newMeterNo:'02322400005173', remarks:'Provide TR ID and T/F Cap' },
  { srNo:'16', installationDate:'07/09/2026', division:'BHARA KAHU',  subDivision:'PATRIATA', feeder:'U.TOPA',  trId:'N/A',    trCapacity:'', referenceNumber:'24141349000540', newMeterNo:'02322400005336', remarks:'Provide TR ID and T/F Cap' },
  { srNo:'17', installationDate:'07/09/2026', division:'BHARA KAHU',  subDivision:'PATRIATA', feeder:'U.TOPA',  trId:'N/A',    trCapacity:'', referenceNumber:'01141349000639', newMeterNo:'02322400005289', remarks:'Provide TR ID and T/F Cap' },
  { srNo:'18', installationDate:'07/09/2026', division:'BHARA KAHU',  subDivision:'PATRIATA', feeder:'U.TOPA',  trId:'N/A',    trCapacity:'', referenceNumber:'28141349000638', newMeterNo:'02322400005152', remarks:'Provide TR ID and T/F Cap' },
  { srNo:'19', installationDate:'07/09/2026', division:'BHARA KAHU',  subDivision:'PATRIATA', feeder:'U.TOPA',  trId:'N/A',    trCapacity:'', referenceNumber:'28141349000642', newMeterNo:'02322400005223', remarks:'Provide TR ID and T/F Cap' },
  { srNo:'20', installationDate:'07/09/2026', division:'BHARA KAHU',  subDivision:'PATRIATA', feeder:'U.TOPA',  trId:'N/A',    trCapacity:'', referenceNumber:'24141349000650', newMeterNo:'02322400005316', remarks:'Provide TR ID and T/F Cap' },
  { srNo:'21', installationDate:'07/09/2026', division:'BHARA KAHU',  subDivision:'PATRIATA', feeder:'U.TOPA',  trId:'N/A',    trCapacity:'', referenceNumber:'24141349000632', newMeterNo:'02322400005146', remarks:'Provide TR ID and T/F Cap' },
  { srNo:'22', installationDate:'08/09/2026', division:'TARIQABAD',   subDivision:'CHAKRI',   feeder:'CHAKRI',  trId:'100000', trCapacity:'', referenceNumber:'19146263181662', newMeterNo:'02322400005309', remarks:'Installed and Commissioned' },
  { srNo:'23', installationDate:'08/09/2026', division:'TARIQABAD',   subDivision:'CHAKRI',   feeder:'CHAKRI',  trId:'100001', trCapacity:'', referenceNumber:'19146263081748', newMeterNo:'02322400005381', remarks:'Installed and Commissioned' },
  { srNo:'24', installationDate:'08/09/2026', division:'TARIQABAD',   subDivision:'CHAKRI',   feeder:'CHAKRI',  trId:'16479',  trCapacity:'', referenceNumber:'19146263281665', newMeterNo:'02322400005279', remarks:'Installed and Commissioned' },
  { srNo:'25', installationDate:'08/09/2026', division:'TARIQABAD',   subDivision:'CHAKRI',   feeder:'CHAKRI',  trId:'99998',  trCapacity:'', referenceNumber:'19146263481853', newMeterNo:'02322400005318', remarks:'Installed and Commissioned' },
  { srNo:'26', installationDate:'08/09/2026', division:'TARIQABAD',   subDivision:'CHAKRI',   feeder:'CHAKRI',  trId:'100002', trCapacity:'', referenceNumber:'19146262981587', newMeterNo:'02322400005434', remarks:'Installed and Commissioned' },
  { srNo:'27', installationDate:'08/09/2026', division:'TARIQABAD',   subDivision:'CHAKRI',   feeder:'CHAKRI',  trId:'100003', trCapacity:'', referenceNumber:'19146262881855', newMeterNo:'02322400005433', remarks:'Installed and Commissioned' },
  { srNo:'28', installationDate:'08/09/2026', division:'TARIQABAD',   subDivision:'CHAKRI',   feeder:'CHAKRI',  trId:'100004', trCapacity:'', referenceNumber:'19146262781937', newMeterNo:'02322400005429', remarks:'Installed and Commissioned' },
  { srNo:'29', installationDate:'08/09/2026', division:'TARIQABAD',   subDivision:'CHAKRI',   feeder:'CHAKRI',  trId:'100006', trCapacity:'', referenceNumber:'19146262581515', newMeterNo:'02322400005313', remarks:'Installed and Commissioned' },
  { srNo:'30', installationDate:'08/09/2026', division:'TARIQABAD',   subDivision:'CHAKRI',   feeder:'CHAKRI',  trId:'99997',  trCapacity:'', referenceNumber:'N/A',            newMeterNo:'02322400005221', remarks:'Installed and Commissioned' },
  { srNo:'31', installationDate:'08/09/2026', division:'TARIQABAD',   subDivision:'CHAKRI',   feeder:'CHAKRI',  trId:'16472',  trCapacity:'', referenceNumber:'19146262376954', newMeterNo:'02322400005437', remarks:'Installed and Commissioned' },
  { srNo:'32', installationDate:'08/09/2026', division:'TARIQABAD',   subDivision:'CHAKRI',   feeder:'CHAKRI',  trId:'16473',  trCapacity:'', referenceNumber:'19146262481169', newMeterNo:'02322400005439', remarks:'Installed and Commissioned' },
  { srNo:'33', installationDate:'08/09/2026', division:'TARIQABAD',   subDivision:'CHAKRI',   feeder:'CHAKRI',  trId:'16471',  trCapacity:'', referenceNumber:'19146261681494', newMeterNo:'02322400005222', remarks:'Installed and Commissioned' },
  { srNo:'34', installationDate:'08/09/2026', division:'BHARA KAHU',  subDivision:'PATRIATA', feeder:'U.TOPA',  trId:'N/A',    trCapacity:'', referenceNumber:'01141349000653', newMeterNo:'02322400005141', remarks:'Provide TR ID and T/F Cap' },
  { srNo:'35', installationDate:'08/09/2026', division:'BHARA KAHU',  subDivision:'PATRIATA', feeder:'U.TOPA',  trId:'N/A',    trCapacity:'', referenceNumber:'01143149000034', newMeterNo:'02322400005319', remarks:'Provide TR ID and T/F Cap' }
];

// ============================================================
// STATE
// ============================================================
let allRecords = [];
let feeders = [...DEFAULT_FEEDERS];
let filteredRecords = [];
let currentPage = 1;
const PAGE_SIZE = 15;
let charts = {};

// ============================================================
// INITIALISATION
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
  loadData();
  bindFilterEvents();
  if (AUTO_REFRESH_MS > 0) {
    setInterval(loadData, AUTO_REFRESH_MS);
  }
});

// ============================================================
// DATA LOADING
// ============================================================
async function loadData() {
  showLoading(true);
  hideError();

  try {
    if (!GOOGLE_SHEET_API_URL) {
      // Demo mode
      document.getElementById('demoNotice').classList.add('visible');
      processData({ success: true, lastUpdated: new Date().toISOString(), feeders: DEFAULT_FEEDERS, records: SAMPLE_RECORDS });
    } else {
      document.getElementById('demoNotice').classList.remove('visible');
      const url = GOOGLE_SHEET_API_URL + (GOOGLE_SHEET_API_URL.includes('?') ? '&' : '?') + 'action=getData&t=' + Date.now();
      const res = await fetch(url);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const json = await res.json();
      if (!json.success) throw new Error(json.error || 'API returned error');
      processData(json);
    }
  } catch (err) {
    console.error(err);
    showError('Unable to load data: ' + err.message + '. Showing sample data.');
    document.getElementById('demoNotice').classList.add('visible');
    processData({ success: true, lastUpdated: new Date().toISOString(), feeders: DEFAULT_FEEDERS, records: SAMPLE_RECORDS });
  } finally {
    showLoading(false);
  }
}

function processData(payload) {
  feeders = (payload.feeders && payload.feeders.length) ? payload.feeders : DEFAULT_FEEDERS;
  // Ensure all master feeders exist
  DEFAULT_FEEDERS.forEach(df => {
    if (!feeders.find(f => f.feeder === df.feeder)) feeders.push(df);
  });

  allRecords = validateRecords(payload.records || []);
  updateLastUpdated(payload.lastUpdated);
  populateFilterDropdowns();
  applyFilters(); // renders everything
}

// ============================================================
// VALIDATION (client-side – authoritative for display)
// ============================================================
function isMissing(val) {
  if (val === null || val === undefined) return true;
  const s = String(val).trim().toUpperCase();
  return s === '' || s === 'N/A' || s === '-' || s === 'NA' || s === 'NULL';
}

function normaliseFeeder(name) {
  if (!name) return '';
  let n = String(name).toUpperCase().trim().replace(/\s+/g, ' ');
  if (n.includes('TOPA')) return 'U.TOPA';
  if (n.includes('CHIRAH')) return 'CHIRAH';
  if (n.includes('TUMAIR')) return 'TUMAIR (NILORE)';
  if (n.includes('MAIRA')) return 'MAIRA SHAROF';
  if (n.includes('PASWAL')) return 'PASWAL';
  if (n === 'CHAKRI') return 'CHAKRI';
  if (n.includes('PARYAL')) return 'PARYAL';
  if (n.includes('REHARA')) return 'REHARA';
  if (n.includes('WAHEED')) return 'WAHEED ABAD';
  if (n.includes('PIR SOHAWA') || n.includes('PIRSOHAWA')) return 'PIR SOHAWA';
  return n;
}

function validateRecords(records) {
  // Duplicate counts
  const refCount = {};
  const meterCount = {};
  records.forEach(r => {
    const ref = String(r.referenceNumber || '').trim();
    const met = String(r.newMeterNo || '').trim();
    if (!isMissing(ref)) refCount[ref] = (refCount[ref] || 0) + 1;
    if (!isMissing(met)) meterCount[met] = (meterCount[met] || 0) + 1;
  });

  return records.map(r => {
    const rec = { ...r };
    rec.division    = String(rec.division || '').toUpperCase().trim();
    rec.subDivision = String(rec.subDivision || '').toUpperCase().trim();
    rec.feeder      = normaliseFeeder(rec.feeder);

    const trId     = String(rec.trId || '').trim();
    const capacity = String(rec.trCapacity || '').trim();
    const ref      = String(rec.referenceNumber || '').trim();
    const meter    = String(rec.newMeterNo || '').trim();
    const remarks  = String(rec.remarks || '').toLowerCase();

    rec.trIdMissing     = isMissing(trId);
    rec.capacityMissing = isMissing(capacity);
    rec.refMissing      = isMissing(ref);
    rec.meterMissing    = isMissing(meter);

    rec.trIdStatus      = rec.trIdMissing ? 'Pending' : 'OK';
    rec.capacityStatus  = rec.capacityMissing ? 'Pending' : 'OK';

    rec.refDuplicate    = (!rec.refMissing && refCount[ref] > 1) ? 'Yes' : 'No';
    rec.meterDuplicate  = (!rec.meterMissing && meterCount[meter] > 1) ? 'Yes' : 'No';
    rec.refDuplicateCount   = refCount[ref] || 0;
    rec.meterDuplicateCount = meterCount[meter] || 0;

    // Overall status
    if (rec.refDuplicate === 'Yes' || rec.meterDuplicate === 'Yes') {
      rec.dataStatus = 'Duplicate Record';
    } else if (rec.trIdMissing || rec.capacityMissing || rec.refMissing) {
      rec.dataStatus = 'Pending Data';
    } else if (remarks.includes('provide') || remarks.includes('missing') || remarks.includes('pending')) {
      rec.dataStatus = 'Pending Data';
    } else if (remarks.includes('installed') || remarks.includes('commissioned')) {
      // Even if capacity missing we already caught it above; here data is complete
      rec.dataStatus = 'Completed';
    } else if (remarks.trim() !== '' && !remarks.includes('installed')) {
      rec.dataStatus = 'Other Issue';
    } else {
      rec.dataStatus = (rec.trIdMissing || rec.capacityMissing) ? 'Pending Data' : 'Completed';
    }

    // Special case: sample data has Capacity always blank → treat as Pending unless we decide otherwise.
    // Per requirements: blank capacity = TR Capacity Pending.
    // Completed only when TR ID + Capacity + valid ref + valid meter + no dups.
    // Adjust Completed definition to require capacity as well:
    if (rec.dataStatus === 'Completed' && rec.capacityMissing) {
      rec.dataStatus = 'Pending Data';
    }

    rec.installationStatus = (remarks.includes('installed') || remarks.includes('commissioned'))
      ? 'Installed & Commissioned'
      : (rec.dataStatus === 'Completed' ? 'Installed & Commissioned' : 'Pending');

    return rec;
  });
}

// ============================================================
// FILTERS
// ============================================================
function populateFilterDropdowns() {
  const divisions = [...new Set(allRecords.map(r => r.division).filter(Boolean))].sort();
  const subDivs   = [...new Set(allRecords.map(r => r.subDivision).filter(Boolean))].sort();
  const feederNames = [...new Set([
    ...feeders.map(f => f.feeder),
    ...allRecords.map(r => r.feeder)
  ].filter(Boolean))].sort();

  fillSelect('filterDivision', divisions);
  fillSelect('filterSubDivision', subDivs);
  fillSelect('filterFeeder', feederNames);
}

function fillSelect(id, items) {
  const sel = document.getElementById(id);
  const current = sel.value;
  sel.innerHTML = '<option value="">All</option>';
  items.forEach(v => {
    const opt = document.createElement('option');
    opt.value = v;
    opt.textContent = v;
    sel.appendChild(opt);
  });
  if (items.includes(current)) sel.value = current;
}

function bindFilterEvents() {
  ['filterDivision', 'filterSubDivision', 'filterFeeder', 'filterStatus'].forEach(id => {
    document.getElementById(id).addEventListener('change', () => {
      currentPage = 1;
      applyFilters();
    });
  });
  document.getElementById('filterDateFrom').addEventListener('change', () => { currentPage = 1; applyFilters(); });
  document.getElementById('filterDateTo').addEventListener('change', () => { currentPage = 1; applyFilters(); });
  document.getElementById('btnResetFilters').addEventListener('click', resetFilters);
  document.getElementById('searchInput').addEventListener('input', debounce(() => {
    currentPage = 1;
    applyFilters();
  }, 250));
  document.getElementById('btnExportCSV').addEventListener('click', () => exportData('csv'));
  document.getElementById('btnExportExcel').addEventListener('click', () => exportData('xlsx'));
  document.getElementById('btnRefresh').addEventListener('click', loadData);
}

function resetFilters() {
  document.getElementById('filterDivision').value = '';
  document.getElementById('filterSubDivision').value = '';
  document.getElementById('filterFeeder').value = '';
  document.getElementById('filterStatus').value = '';
  document.getElementById('filterDateFrom').value = '';
  document.getElementById('filterDateTo').value = '';
  document.getElementById('searchInput').value = '';
  currentPage = 1;
  applyFilters();
}

function parseDate(dmy) {
  if (!dmy) return null;
  const parts = String(dmy).split(/[\/\-\.]/);
  if (parts.length !== 3) return null;
  // DD/MM/YYYY
  const d = parseInt(parts[0], 10);
  const m = parseInt(parts[1], 10) - 1;
  const y = parseInt(parts[2], 10);
  if (isNaN(d) || isNaN(m) || isNaN(y)) return null;
  return new Date(y, m, d);
}

function applyFilters() {
  const div   = document.getElementById('filterDivision').value;
  const sub   = document.getElementById('filterSubDivision').value;
  const fed   = document.getElementById('filterFeeder').value;
  const status = document.getElementById('filterStatus').value;
  const from  = document.getElementById('filterDateFrom').value;
  const to    = document.getElementById('filterDateTo').value;
  const search = (document.getElementById('searchInput').value || '').toLowerCase().trim();

  const fromDate = from ? new Date(from) : null;
  const toDate   = to   ? new Date(to)   : null;

  filteredRecords = allRecords.filter(r => {
    if (div && r.division !== div) return false;
    if (sub && r.subDivision !== sub) return false;
    if (fed && r.feeder !== fed) return false;

    if (status) {
      if (status === 'Completed' && r.dataStatus !== 'Completed') return false;
      if (status === 'Pending Data' && r.dataStatus !== 'Pending Data') return false;
      if (status === 'Duplicate Record' && r.dataStatus !== 'Duplicate Record') return false;
      if (status === 'Other Issue' && r.dataStatus !== 'Other Issue') return false;
      if (status === 'TR ID Pending' && !r.trIdMissing) return false;
      if (status === 'Capacity Pending' && !r.capacityMissing) return false;
      if (status === 'Duplicate Reference' && r.refDuplicate !== 'Yes') return false;
      if (status === 'Duplicate Meter' && r.meterDuplicate !== 'Yes') return false;
    }

    if (fromDate || toDate) {
      const rd = parseDate(r.installationDate);
      if (!rd) return false;
      if (fromDate && rd < fromDate) return false;
      if (toDate) {
        const end = new Date(toDate);
        end.setHours(23, 59, 59, 999);
        if (rd > end) return false;
      }
    }

    if (search) {
      const hay = [
        r.srNo, r.installationDate, r.division, r.subDivision, r.feeder,
        r.trId, r.trCapacity, r.referenceNumber, r.newMeterNo, r.remarks, r.dataStatus
      ].join(' ').toLowerCase();
      if (!hay.includes(search)) return false;
    }
    return true;
  });

  renderAll();
}

// ============================================================
// RENDER
// ============================================================
function renderAll() {
  renderKPIs();
  renderFeederTable();
  renderPendingSubdivision();
  renderCharts();
  renderDetailTable();
}

function renderKPIs() {
  const totalFeeders = feeders.length;
  const totalRecords = allRecords.length; // overall, not filtered
  const completed = allRecords.filter(r => r.dataStatus === 'Completed').length;
  const pendingData = allRecords.filter(r => r.dataStatus === 'Pending Data').length;
  const trIdPending = allRecords.filter(r => r.trIdMissing).length;
  const capPending = allRecords.filter(r => r.capacityMissing).length;
  const dupRef = allRecords.filter(r => r.refDuplicate === 'Yes').length;
  const dupMeter = allRecords.filter(r => r.meterDuplicate === 'Yes').length;
  const overallPct = totalRecords ? Math.round((completed / totalRecords) * 100) : 0;

  document.getElementById('kpiTotalFeeders').textContent = totalFeeders;
  document.getElementById('kpiTotalRecords').textContent = totalRecords;
  document.getElementById('kpiCompleted').textContent = completed;
  document.getElementById('kpiPending').textContent = pendingData;
  document.getElementById('kpiTrIdPending').textContent = trIdPending;
  document.getElementById('kpiCapPending').textContent = capPending;
  document.getElementById('kpiDupRef').textContent = dupRef;
  document.getElementById('kpiDupMeter').textContent = dupMeter;
  document.getElementById('kpiOverallPct').textContent = overallPct + '%';
}

function renderFeederTable() {
  const tbody = document.getElementById('feederTableBody');
  tbody.innerHTML = '';

  feeders.forEach(f => {
    const rows = allRecords.filter(r => r.feeder === f.feeder);
    const total = rows.length;
    const completed = rows.filter(r => r.dataStatus === 'Completed').length;
    const pending = total - completed;
    const trIdP = rows.filter(r => r.trIdMissing).length;
    const capP = rows.filter(r => r.capacityMissing).length;
    const dups = rows.filter(r => r.refDuplicate === 'Yes' || r.meterDuplicate === 'Yes').length;
    const pct = total ? Math.round((completed / total) * 100) : 0;
    const barClass = pct >= 70 ? 'high' : pct >= 30 ? 'mid' : 'low';

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${esc(f.division)}</td>
      <td>${esc(f.subDivision)}</td>
      <td><strong>${esc(f.feeder)}</strong></td>
      <td>${total}</td>
      <td>${completed}</td>
      <td>${pending}</td>
      <td>${trIdP}</td>
      <td>${capP}</td>
      <td>${dups}</td>
      <td class="progress-cell">
        <span class="progress-pct">${pct}%</span>
        <div class="progress-bar-bg"><div class="progress-bar-fill ${barClass}" style="width:${pct}%"></div></div>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function renderPendingSubdivision() {
  const tbody = document.getElementById('pendingSubTableBody');
  tbody.innerHTML = '';

  // Group by Division + Sub Division + Feeder for pending items
  const map = {};
  allRecords.forEach(r => {
    if (r.dataStatus === 'Completed' && !r.trIdMissing && !r.capacityMissing && r.refDuplicate !== 'Yes' && r.meterDuplicate !== 'Yes') return;
    const key = r.division + '|' + r.subDivision + '|' + r.feeder;
    if (!map[key]) {
      map[key] = {
        division: r.division,
        subDivision: r.subDivision,
        feeder: r.feeder,
        totalPending: 0,
        missingTrId: 0,
        missingCap: 0,
        dupRef: 0,
        dupMeter: 0,
        other: 0
      };
    }
    const g = map[key];
    g.totalPending++;
    if (r.trIdMissing) g.missingTrId++;
    if (r.capacityMissing) g.missingCap++;
    if (r.refDuplicate === 'Yes') g.dupRef++;
    if (r.meterDuplicate === 'Yes') g.dupMeter++;
    if (r.dataStatus === 'Other Issue') g.other++;
  });

  // Also include feeders with zero records as pending awareness? Skip – only show actual pending.
  const groups = Object.values(map).sort((a, b) => b.totalPending - a.totalPending);

  if (groups.length === 0) {
    tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;padding:1.5rem;color:var(--success);">No pending data – all records complete.</td></tr>';
    return;
  }

  groups.forEach(g => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${esc(g.division)}</td>
      <td>${esc(g.subDivision)}</td>
      <td><strong>${esc(g.feeder)}</strong></td>
      <td><strong>${g.totalPending}</strong></td>
      <td>${g.missingTrId || '–'}</td>
      <td>${g.missingCap || '–'}</td>
      <td>${g.dupRef || '–'}</td>
      <td>${g.dupMeter || '–'}</td>
      <td>${g.other || '–'}</td>
    `;
    tbody.appendChild(tr);
  });
}

function renderDetailTable() {
  const tbody = document.getElementById('detailTableBody');
  tbody.innerHTML = '';

  const total = filteredRecords.length;
  const start = (currentPage - 1) * PAGE_SIZE;
  const pageRows = filteredRecords.slice(start, start + PAGE_SIZE);

  pageRows.forEach(r => {
    const tr = document.createElement('tr');
    if (r.dataStatus === 'Pending Data') tr.classList.add('row-pending');
    if (r.dataStatus === 'Duplicate Record') tr.classList.add('row-duplicate');

    tr.innerHTML = `
      <td>${esc(r.srNo)}</td>
      <td>${esc(r.installationDate)}</td>
      <td>${esc(r.division)}</td>
      <td>${esc(r.subDivision)}</td>
      <td>${esc(r.feeder)}</td>
      <td>${r.trIdMissing ? '<span class="badge badge-trid">Missing</span>' : esc(r.trId)}</td>
      <td>${r.capacityMissing ? '<span class="badge badge-capacity">Missing</span>' : esc(r.trCapacity)}</td>
      <td style="font-family:monospace;font-size:0.78rem;">${esc(r.referenceNumber)}</td>
      <td style="font-family:monospace;font-size:0.78rem;">${esc(r.newMeterNo)}</td>
      <td>${r.refDuplicate === 'Yes' ? `<span class="badge badge-duplicate">Yes (${r.refDuplicateCount})</span>` : 'No'}</td>
      <td>${r.meterDuplicate === 'Yes' ? `<span class="badge badge-duplicate">Yes (${r.meterDuplicateCount})</span>` : 'No'}</td>
      <td>${statusBadge(r.dataStatus)}</td>
      <td title="${esc(r.remarks)}">${esc(truncate(r.remarks, 40))}</td>
    `;
    tbody.appendChild(tr);
  });

  renderPagination(total);
}

function statusBadge(status) {
  if (status === 'Completed') return '<span class="badge badge-completed">Completed</span>';
  if (status === 'Pending Data') return '<span class="badge badge-pending">Pending Data</span>';
  if (status === 'Duplicate Record') return '<span class="badge badge-duplicate">Duplicate</span>';
  return `<span class="badge badge-other">${esc(status)}</span>`;
}

function renderPagination(total) {
  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  if (currentPage > pages) currentPage = pages;
  const info = document.getElementById('paginationInfo');
  const start = total === 0 ? 0 : (currentPage - 1) * PAGE_SIZE + 1;
  const end = Math.min(currentPage * PAGE_SIZE, total);
  info.textContent = `Showing ${start}–${end} of ${total}`;

  const controls = document.getElementById('paginationControls');
  controls.innerHTML = '';

  const prev = document.createElement('button');
  prev.textContent = '‹ Prev';
  prev.disabled = currentPage <= 1;
  prev.onclick = () => { currentPage--; renderDetailTable(); };
  controls.appendChild(prev);

  // Simple page numbers (max 7)
  let startP = Math.max(1, currentPage - 3);
  let endP = Math.min(pages, startP + 6);
  startP = Math.max(1, endP - 6);
  for (let i = startP; i <= endP; i++) {
    const b = document.createElement('button');
    b.textContent = i;
    if (i === currentPage) b.classList.add('active');
    b.onclick = () => { currentPage = i; renderDetailTable(); };
    controls.appendChild(b);
  }

  const next = document.createElement('button');
  next.textContent = 'Next ›';
  next.disabled = currentPage >= pages;
  next.onclick = () => { currentPage++; renderDetailTable(); };
  controls.appendChild(next);
}

// ============================================================
// CHARTS
// ============================================================
function renderCharts() {
  renderFeederProgressChart();
  renderPendingClassificationChart();
  renderDivisionProgressChart();
  renderInstallationTrendChart();
}

function renderFeederProgressChart() {
  const labels = feeders.map(f => f.feeder);
  const completed = feeders.map(f => allRecords.filter(r => r.feeder === f.feeder && r.dataStatus === 'Completed').length);
  const pending = feeders.map(f => allRecords.filter(r => r.feeder === f.feeder && r.dataStatus !== 'Completed').length);

  const ctx = document.getElementById('chartFeederProgress').getContext('2d');
  if (charts.feeder) charts.feeder.destroy();
  charts.feeder = new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [
        { label: 'Completed', data: completed, backgroundColor: '#1a7a4c', borderRadius: 4 },
        { label: 'Pending', data: pending, backgroundColor: '#b36b00', borderRadius: 4 }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { position: 'top' } },
      scales: {
        x: { stacked: false, ticks: { maxRotation: 45, minRotation: 30, font: { size: 10 } } },
        y: { beginAtZero: true, ticks: { stepSize: 1 } }
      }
    }
  });
}

function renderPendingClassificationChart() {
  const trId = allRecords.filter(r => r.trIdMissing).length;
  const cap  = allRecords.filter(r => r.capacityMissing && !r.trIdMissing).length; // avoid double count preference
  const dupR = allRecords.filter(r => r.refDuplicate === 'Yes').length;
  const dupM = allRecords.filter(r => r.meterDuplicate === 'Yes' && r.refDuplicate !== 'Yes').length;
  const other = allRecords.filter(r => r.dataStatus === 'Other Issue').length;

  // Simpler exclusive-ish buckets for the donut
  const data = [
    allRecords.filter(r => r.trIdMissing).length,
    allRecords.filter(r => r.capacityMissing).length,
    allRecords.filter(r => r.refDuplicate === 'Yes').length,
    allRecords.filter(r => r.meterDuplicate === 'Yes').length,
    allRecords.filter(r => r.dataStatus === 'Other Issue').length
  ];

  const ctx = document.getElementById('chartPendingClass').getContext('2d');
  if (charts.pending) charts.pending.destroy();
  charts.pending = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['TR ID Pending', 'Capacity Pending', 'Duplicate Ref', 'Duplicate Meter', 'Other Issue'],
      datasets: [{
        data,
        backgroundColor: ['#c2410c', '#b36b00', '#b42318', '#912018', '#475467'],
        borderWidth: 2,
        borderColor: '#fff'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: 'right', labels: { boxWidth: 12, font: { size: 11 } } }
      }
    }
  });
}

function renderDivisionProgressChart() {
  const divisions = [...new Set(feeders.map(f => f.division))];
  const completed = divisions.map(d => allRecords.filter(r => r.division === d && r.dataStatus === 'Completed').length);
  const pending = divisions.map(d => allRecords.filter(r => r.division === d && r.dataStatus !== 'Completed').length);

  const ctx = document.getElementById('chartDivision').getContext('2d');
  if (charts.division) charts.division.destroy();
  charts.division = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: divisions,
      datasets: [
        { label: 'Completed', data: completed, backgroundColor: '#1a7a4c', borderRadius: 4 },
        { label: 'Pending', data: pending, backgroundColor: '#b36b00', borderRadius: 4 }
      ]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { position: 'top' } },
      scales: { x: { beginAtZero: true, ticks: { stepSize: 1 } } }
    }
  });
}

function renderInstallationTrendChart() {
  const dateMap = {};
  allRecords.forEach(r => {
    const d = r.installationDate || 'Unknown';
    dateMap[d] = (dateMap[d] || 0) + 1;
  });
  const sorted = Object.keys(dateMap).sort((a, b) => {
    const da = parseDate(a); const db = parseDate(b);
    if (!da) return 1; if (!db) return -1;
    return da - db;
  });

  const ctx = document.getElementById('chartTrend').getContext('2d');
  if (charts.trend) charts.trend.destroy();
  charts.trend = new Chart(ctx, {
    type: 'line',
    data: {
      labels: sorted,
      datasets: [{
        label: 'Installations',
        data: sorted.map(d => dateMap[d]),
        borderColor: '#0b3d5c',
        backgroundColor: 'rgba(11, 61, 92, 0.12)',
        fill: true,
        tension: 0.3,
        pointRadius: 4,
        pointBackgroundColor: '#0b3d5c'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
    }
  });
}

// ============================================================
// EXPORT
// ============================================================
function exportData(format) {
  const rows = filteredRecords.length ? filteredRecords : allRecords;
  const headers = [
    'Sr. No.', 'Installation Date', 'Division', 'Sub Division', 'Feeder',
    'TR ID', 'TR Capacity', 'Reference Number', 'New Meter No.',
    'Ref No. Duplicate', 'Meter No. Duplicate', 'Status', 'Remarks'
  ];

  const data = rows.map(r => [
    r.srNo, r.installationDate, r.division, r.subDivision, r.feeder,
    r.trId, r.trCapacity, r.referenceNumber, r.newMeterNo,
    r.refDuplicate, r.meterDuplicate, r.dataStatus, r.remarks
  ]);

  if (format === 'csv') {
    const csv = [headers.join(',')].concat(
      data.map(row => row.map(c => {
        const s = String(c ?? '');
        return s.includes(',') || s.includes('"') || s.includes('\n')
          ? '"' + s.replace(/"/g, '""') + '"'
          : s;
      }).join(','))
    ).join('\n');
    downloadBlob(csv, 'IESCO_AMI_HighLoss_Feeders.csv', 'text/csv;charset=utf-8;');
  } else {
    // Simple HTML table that Excel can open
    let html = '<html><head><meta charset="UTF-8"></head><body><table border="1"><tr>';
    headers.forEach(h => { html += '<th>' + h + '</th>'; });
    html += '</tr>';
    data.forEach(row => {
      html += '<tr>';
      row.forEach(c => { html += '<td>' + String(c ?? '').replace(/</g, '&lt;') + '</td>'; });
      html += '</tr>';
    });
    html += '</table></body></html>';
    downloadBlob(html, 'IESCO_AMI_HighLoss_Feeders.xls', 'application/vnd.ms-excel');
  }
}

function downloadBlob(content, filename, mime) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// ============================================================
// UTILITIES
// ============================================================
function esc(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function truncate(str, len) {
  if (!str) return '';
  return str.length > len ? str.slice(0, len) + '…' : str;
}

function debounce(fn, ms) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

function showLoading(show) {
  document.getElementById('loadingOverlay').style.display = show ? 'flex' : 'none';
}

function showError(msg) {
  const el = document.getElementById('errorBanner');
  el.textContent = msg;
  el.classList.add('visible');
}

function hideError() {
  document.getElementById('errorBanner').classList.remove('visible');
}

function updateLastUpdated(iso) {
  const el = document.getElementById('lastUpdateText');
  if (!iso) {
    el.textContent = '—';
    return;
  }
  try {
    const d = new Date(iso);
    const dd = String(d.getDate()).padStart(2, '0');
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const yyyy = d.getFullYear();
    const hh = String(d.getHours()).padStart(2, '0');
    const mi = String(d.getMinutes()).padStart(2, '0');
    el.textContent = `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
  } catch {
    el.textContent = iso;
  }
}
